package com.example.ejercicio_entregar;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button bt1, bt2;
    Spinner spn;
    String dificultad;
    ArrayList<Bomba> arrayBombas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = findViewById(R.id.button1);
        bt2 = findViewById(R.id.button2);
        spn = findViewById(R.id.spinnerPersonajes);

        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);


        arrayBombas.add(new Bomba(getResources().getString(R.string.ninguno), 0));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minacla), R.drawable.bomba));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minabomb), R.drawable.bombabomber));
        arrayBombas.add(new Bomba(getResources().getString(R.string.dinamita), R.drawable.dinamita));
        arrayBombas.add(new Bomba(getResources().getString(R.string.granada), R.drawable.granada));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minasub), R.drawable.mina));
        arrayBombas.add(new Bomba(getResources().getString(R.string.coctelmolo), R.drawable.coctelmolotov));
        MiAdaptadorBomba adapter = new MiAdaptadorBomba(MainActivity.this, R.layout.layoutminas, arrayBombas);
        spn.setAdapter(adapter);
        spn.setSelection(-1);
   spn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
       @Override
       public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
           if(i>0){
               Toast.makeText(MainActivity.this, arrayBombas.get(i).getNombre(), Toast.LENGTH_SHORT).show();
           }

       }

       @Override
       public void onNothingSelected(AdapterView<?> adapterView) {

       }
   });

    }

    public void onClick(View view){
        if(view.getId() == R.id.button1){
            instruccionesDialog();
        }else if(view.getId() == R.id.button2){
            dificultadDialog();
        }
    }

    public void instruccionesDialog(){

        AlertDialog.Builder dlgInstrucciones = new AlertDialog.Builder(MainActivity.this);
        dlgInstrucciones.setTitle("Instrucciones");
        dlgInstrucciones.setMessage("Cuando pulsas en una casilla, sale un numero que identifica cuantas minas hay alrededor. Ten cuidado porque si pulsas " +
                "en una casilla que tenga una mina escondida, perderas. Si crees o tienes certeza de que hay una mina, haz un click largo " +
                "sobre la casilla para señalarla. No hagas un click largo en una casilla donde no hay una mina porqe perderas. Ganas una vez " +
                "hayas encontrado todas las minas.");
        dlgInstrucciones.setPositiveButton("Ok", (dialogInterface, i) -> dialogInterface.dismiss());
        dlgInstrucciones.create().show();


    }

    public void dificultadDialog(){
         AlertDialog.Builder dlgDificultad = new AlertDialog.Builder(this);

         dlgDificultad.setTitle("Dificultad a elegir");
         dlgDificultad.setSingleChoiceItems(R.array.dificultad, -1, (dialogInterface, i) -> dificultad = getResources().getStringArray(R.array.dificultad)[i]);

         dlgDificultad.setPositiveButton("Volver", (dialogInterface, i) -> {
             if (!dificultad.isEmpty()) {
                 Toast.makeText(MainActivity.this, dificultad, Toast.LENGTH_SHORT).show();
             } else {
                 Toast.makeText(MainActivity.this, "No seleccionaste ningún elemento", Toast.LENGTH_SHORT).show();
             }
         });

        dlgDificultad.show();
    }
}