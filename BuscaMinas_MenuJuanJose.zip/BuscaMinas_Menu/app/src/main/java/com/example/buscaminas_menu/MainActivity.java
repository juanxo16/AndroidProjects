package com.example.buscaminas_menu;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String dificultad;
    ArrayList<Bomba> arrayBombas = new ArrayList<>();
    Spinner spn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        arrayBombas.add(new Bomba(getResources().getString(R.string.ninguno), 0));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minacla), R.drawable.bomba));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minabomb), R.drawable.bombabomber));
        arrayBombas.add(new Bomba(getResources().getString(R.string.dinamita), R.drawable.dinamita));
        arrayBombas.add(new Bomba(getResources().getString(R.string.granada), R.drawable.granada));
        arrayBombas.add(new Bomba(getResources().getString(R.string.minasub), R.drawable.mina));
        arrayBombas.add(new Bomba(getResources().getString(R.string.coctelmolo), R.drawable.coctelmolotov));





    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.instrucciones){
            instruccionesDialog();
        }else if(item.getItemId()==R.id.comenzar){
            Toast.makeText(this, "Has seleccionado " + item.getTitle(), Toast.LENGTH_SHORT).show();
        }else if(item.getItemId()==R.id.configurar){
            dificultadDialog();
        }else if(item.getItemId()==R.id.personajes){
            spn = findViewById(R.id.spinner);

            // Asegúrate de que el Spinner esté visible y configura el adaptador antes de desplegarlo
            spn.setVisibility(View.VISIBLE);

            // Configura el adaptador para el Spinner
            MiAdaptadorBomba adapter = new MiAdaptadorBomba(MainActivity.this, R.layout.layout_minas, arrayBombas);
            spn.setAdapter(adapter);

            // Despliega el Spinner automáticamente
            spn.performClick();

            spn.setSelection(0);
            spn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (i > 0) {
                        Toast.makeText(MainActivity.this, arrayBombas.get(i).getNombre(), Toast.LENGTH_SHORT).show();
                        spn.setVisibility(View.INVISIBLE);
                    }else{
                        spn.setVisibility(View.INVISIBLE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    // No se seleccionó nada

                }
            });
        }
        return super.onOptionsItemSelected(item);
    }

    public void instruccionesDialog(){

        AlertDialog.Builder dlgInstrucciones = new AlertDialog.Builder(MainActivity.this);
        dlgInstrucciones.setTitle("Instrucciones");
        dlgInstrucciones.setMessage("Cuando pulsas en una casilla, sale un numero que identifica cuantas minas hay alrededor. Ten cuidado porque si pulsas " +
                "en una casilla que tenga una mina escondida, perderas. Si crees o tienes certeza de que hay una mina, haz un click largo " +
                "sobre la casilla para señalarla. No hagas un click largo en una casilla donde no hay una mina porqe perderas. Ganas una vez " +
                "hayas encontrado todas las minas.");
        dlgInstrucciones.setPositiveButton("Ok", (dialogInterface, i) -> dialogInterface.dismiss());
        dlgInstrucciones.create().show();


    }

    public void dificultadDialog(){
        AlertDialog.Builder dlgDificultad = new AlertDialog.Builder(this);

        dlgDificultad.setTitle("Dificultad a elegir");
        dlgDificultad.setSingleChoiceItems(R.array.dificultad, -1, (dialogInterface, i) -> dificultad = getResources().getStringArray(R.array.dificultad)[i]);

        dlgDificultad.setPositiveButton("Volver", (dialogInterface, i) -> {
            if (dificultad != null && !dificultad.isEmpty()) {
                Toast.makeText(MainActivity.this, dificultad, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "No seleccionaste ningún elemento", Toast.LENGTH_SHORT).show();
            }
        });

        dlgDificultad.show();
    }
}